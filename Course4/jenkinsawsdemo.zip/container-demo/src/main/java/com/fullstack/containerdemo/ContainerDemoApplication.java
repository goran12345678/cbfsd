package com.fullstack.containerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContainerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContainerDemoApplication.class, args);
	}

}
